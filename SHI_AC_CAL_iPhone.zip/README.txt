SHI AC CAL - iPhone installable web app

1. Put these files on a web host (GitHub Pages, Netlify, etc.).
2. Open the HTTPS site in Safari on iPhone.
3. Tap Share -> Add to Home Screen.
4. Open SHI AC CAL from the Home Screen.

This version calculates an estimated BTU requirement from room area, occupants and sunlight.
For a true native iOS .ipa/App Store build, the same logic can be moved into SwiftUI and signed with Apple/Xcode.
